A Pen created at CodePen.io. You can find this one at http://codepen.io/Lewitje/pen/BNNJjo.

 A ultra simple login screen on a calm breezy day,